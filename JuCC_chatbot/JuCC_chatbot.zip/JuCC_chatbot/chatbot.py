import os
import google.generativeai as genai

genai.configure(api_key="AIzaSyB3waCyrFLd4uGNT_cTsYBhhclVaHvfPn0")

# Create the model
generation_config = {
  "temperature": 2,
  "top_p": 0.95,
  "top_k": 40,
  "max_output_tokens": 500,
  "response_mime_type": "text/plain",
}

model = genai.GenerativeModel(
  model_name="gemini-1.5-flash",
  generation_config=generation_config,
  system_instruction="You are a cybersecurity awareness assistant working as part of the JuCC awareness team. Your role is to answer awareness questions in cybersecurity based on trusted global standards such as those from CISA (Cybersecurity and Infrastructure Security Agency) and NCSC (National Cyber Security Centre).\n\nAlways give answers that are short, simple, and easy to understand, avoiding technical jargon. Your audience includes students with limited cybersecurity knowledge, so be friendly and clear in your responses.\n\nWhen relevant, briefly mention whether the advice is based on CISA, NCSC, or both, to show the source of the information.\n",
)

history=[]
print("JuCCBot: Hello, how can I help you?")

while True:
    user_input=input("You: ")

    chat_session = model.start_chat(
    history=history
    )
    response = chat_session.send_message(user_input)
    model_response=response.text
    print(f'JuCCBot: {model_response}')
    print()

    history.append({"role":"user","parts":[user_input]})
    history.append({"role":"model","parts":[model_response]})